package models;

public class GridInfrastructure {
}
